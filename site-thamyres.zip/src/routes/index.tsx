import { createFileRoute } from "@tanstack/react-router";
import heroImg from "@/assets/hero-garden.jpg.asset.json";
import portraitAsset from "@/assets/thamyres.jpg.asset.json";
import leafImg from "@/assets/psicodrama-livro.jpg.asset.json";
import { useReveal } from "@/hooks/use-reveal";

export const Route = createFileRoute("/")({
  component: Index,
});

const WHATSAPP =
  "https://wa.me/5562998050979?text=Ol%C3%A1%2C%20Thamyres!%20Gostaria%20de%20mais%20informa%C3%A7%C3%B5es%20sobre%20seus%20atendimentos.";

function Index() {
  useReveal();
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Nav />
      <Hero />
      <About />
      <Services />
      <HowItWorks />
      <Psicodrama />
      <ForWhom />
      <Ethics />
      <Faq />
      <Contact />
      <Footer />
    </div>
  );
}

function Nav() {
  return (
    <header className="absolute top-0 left-0 right-0 z-20">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <a href="#top" className="font-serif text-lg tracking-tight text-primary">
          Thamyres Meireles
        </a>
        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#sobre" className="hover:text-primary transition-colors">Sobre</a>
          <a href="#servicos" className="hover:text-primary transition-colors">Serviços</a>
          <a href="#psicodrama" className="hover:text-primary transition-colors">Psicodrama</a>
          <a href="#contato" className="hover:text-primary transition-colors">Contato</a>
        </nav>
        <a
          href={WHATSAPP}
          target="_blank"
          rel="noopener noreferrer"
          className="hidden rounded-full border border-primary/30 bg-background/60 px-4 py-2 text-sm text-primary backdrop-blur transition-colors hover:bg-primary hover:text-primary-foreground md:inline-flex"
        >
          Agendar
        </a>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-10 px-6 pt-32 pb-20 md:grid-cols-2 md:gap-16 md:pt-40 md:pb-28">
        <div className="flex flex-col justify-center">
          <span className="mb-6 inline-flex w-fit items-center gap-2 rounded-full bg-sage-soft px-3 py-1 text-xs uppercase tracking-widest text-primary">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            Psicóloga Clínica · CRP 09/19524
          </span>
          <h1 className="font-serif text-4xl leading-[1.05] text-primary md:text-6xl">
            Um espaço seguro para cuidar da sua{" "}
            <em className="italic text-sage">saúde emocional</em>.
          </h1>
          <p className="mt-6 max-w-lg text-base leading-relaxed text-muted-foreground md:text-lg">
            Atendo mulheres adultas que lidam com ansiedade, dificuldades nos
            relacionamentos e sofrimento ligado ao trabalho e à carreira, com
            uma escuta ética, acolhedora e respeitosa.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href={WHATSAPP}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm text-primary-foreground transition-all hover:bg-sage-deep hover:shadow-lg"
            >
              Agendar atendimento
              <span aria-hidden>→</span>
            </a>
            <a
              href="#sobre"
              className="inline-flex items-center rounded-full border border-primary/20 px-6 py-3 text-sm text-primary transition-colors hover:bg-sage-soft"
            >
              Conhecer meu trabalho
            </a>
          </div>
          <p className="mt-8 text-xs uppercase tracking-widest text-muted-foreground">
            Atendimento online · Brasil e exterior
          </p>
        </div>
        <div className="relative">
          <div className="relative overflow-hidden rounded-[2rem] bg-sage-soft aspect-[4/5]">
            <img
              src={heroImg.url}
              alt="Jardim ao entardecer com duas cadeiras brancas entre flores"
              width={1400}
              height={1600}
              className="h-full w-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section data-reveal id="sobre" className="border-t border-border/60 bg-cream">
      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-12 px-6 py-20 md:grid-cols-5 md:py-28">
        <div className="md:col-span-2">
          <div className="overflow-hidden rounded-[2rem] aspect-[4/5]">
            <img
              src={portraitAsset.url}
              alt="Thamyres Meireles, psicóloga clínica"
              width={1000}
              height={1200}
              loading="lazy"
              className="h-full w-full object-cover"
            />
          </div>
        </div>
        <div className="md:col-span-3 md:pl-8">
          <p className="text-xs uppercase tracking-widest text-sage">Apresentação</p>
          <h2 className="mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl">
            Sou Thamyres Meireles, psicóloga clínica.
          </h2>
          <div className="mt-6 space-y-4 text-base leading-relaxed text-muted-foreground">
            <p>
              Minha atuação é guiada pelo cuidado com a saúde emocional e pelo
              respeito à singularidade de cada pessoa. Acredito na psicoterapia
              como um espaço de encontro consigo, de elaboração das dores e de
              construção de novas possibilidades de existir.
            </p>
            <p>
              Sou formada pela Pontifícia Universidade Católica de Goiás, com
              mérito acadêmico <em>Summa Cum Laude</em>, e atuo com a abordagem
              do <strong className="text-primary font-medium">Psicodrama</strong>,
              que favorece a expressão emocional, a ampliação da consciência e
              o fortalecimento da espontaneidade.
            </p>
          </div>
          <dl className="mt-10 grid grid-cols-2 gap-6 border-t border-border/60 pt-8">
            <div>
              <dt className="text-xs uppercase tracking-widest text-sage">Registro</dt>
              <dd className="mt-1 font-serif text-xl text-primary">CRP 09/19524</dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-widest text-sage">Abordagem</dt>
              <dd className="mt-1 font-serif text-xl text-primary">Psicodrama</dd>
            </div>
          </dl>
        </div>
      </div>
    </section>
  );
}

const services = [
  {
    title: "Psicoterapia",
    desc: "Acompanhamento contínuo para mulheres adultas, em encontros semanais de 50 minutos, com escuta ética e vínculo terapêutico.",
    tag: "Semanal",
  },
  {
    title: "Plantão Psicológico",
    desc: "Atendimento pontual para momentos de crise, urgência emocional ou quando você precisa de escuta imediata, sem compromisso de continuidade.",
    tag: "Sessão única",
  },
  {
    title: "Consultoria de Carreira",
    desc: "Encontros únicos para analisar juntas as possibilidades do momento: transição de carreira, busca por um novo emprego e reposicionamento profissional.",
    tag: "Encontro único",
  },
];

function Services() {
  return (
    <section data-reveal id="servicos" className="border-t border-border/60">
      <div className="mx-auto max-w-6xl px-6 py-20 md:py-28">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-xl">
            <p className="text-xs uppercase tracking-widest text-sage">Serviços</p>
            <h2 className="mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl">
              Cuidado que respeita o seu tempo.
            </h2>
          </div>
          <p className="max-w-sm text-sm text-muted-foreground">
            Três formas de acompanhamento, pensadas para diferentes momentos da
            vida. Todos os atendimentos acontecem online.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-3">
          {services.map((s, i) => (
            <article
              key={s.title}
              className="group relative flex flex-col justify-between rounded-3xl border border-border/70 bg-card p-8 transition-all hover:border-sage hover:shadow-lg hover:-translate-y-1"
            >
              <div>
                <span className="inline-flex items-center rounded-full bg-sage-soft px-3 py-1 text-[10px] uppercase tracking-widest text-primary">
                  {s.tag}
                </span>
                <h3 className="mt-6 font-serif text-2xl text-primary">{s.title}</h3>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  {s.desc}
                </p>
              </div>
              <div className="mt-10 flex items-center justify-between border-t border-border/60 pt-5">
                <span className="font-serif text-sm text-sage">
                  0{i + 1}
                </span>
                <a
                  href={WHATSAPP}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs uppercase tracking-widest text-primary transition-colors group-hover:text-sage-deep"
                >
                  Agendar →
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    {
      n: "01",
      t: "Primeiro contato",
      d: "Você me escreve pelo WhatsApp e conversamos brevemente sobre a sua demanda.",
    },
    {
      n: "02",
      t: "Sessão inicial",
      d: "Nosso primeiro encontro é um espaço para nos conhecermos e alinharmos objetivos.",
    },
    {
      n: "03",
      t: "Processo terapêutico",
      d: "Encontros semanais de 50 minutos, online, em plataforma segura e sigilosa.",
    },
  ];
  return (
    <section data-reveal className="border-t border-border/60 bg-sage-soft/40">
      <div className="mx-auto max-w-6xl px-6 py-20 md:py-28">
        <div className="max-w-2xl">
          <p className="text-xs uppercase tracking-widest text-sage">Como funciona</p>
          <h2 className="mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl">
            Um processo construído em conjunto.
          </h2>
          <p className="mt-6 text-base leading-relaxed text-muted-foreground">
            A psicoterapia se constrói a partir da escuta, do vínculo e do
            respeito ao seu tempo — conforme as normas do Conselho Federal de
            Psicologia.
          </p>
        </div>
        <ol className="mt-14 grid grid-cols-1 gap-8 md:grid-cols-3">
          {steps.map((s) => (
            <li key={s.n} className="relative border-t border-primary/20 pt-6">
              <span className="font-serif text-3xl text-sage">{s.n}</span>
              <h3 className="mt-3 font-serif text-xl text-primary">{s.t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {s.d}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Psicodrama() {
  return (
    <section data-reveal id="psicodrama" className="border-t border-border/60">
      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-12 px-6 py-20 md:grid-cols-2 md:py-28">
        <div className="order-2 md:order-1">
          <div className="overflow-hidden rounded-[2rem] aspect-[4/3]">
            <img
              src={leafImg.url}
              alt="Thamyres sorrindo, segurando o livro Lições de Psicodrama"
              width={1200}
              height={900}
              loading="lazy"
              className="h-full w-full object-cover"
            />
          </div>
        </div>
        <div className="order-1 flex flex-col justify-center md:order-2">
          <p className="text-xs uppercase tracking-widest text-sage">Abordagem</p>
          <h2 className="mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl">
            Psicodrama: espontaneidade e presença.
          </h2>
          <div className="mt-6 space-y-4 text-base leading-relaxed text-muted-foreground">
            <p>
              O Psicodrama é facilitador da manifestação das ideias, dos
              conflitos sobre um tema, dos dilemas morais, impedimentos e
              possibilidades de expressão em determinada situação.
            </p>
            <p>
              Fundamentado na teoria do momento e no princípio da
              espontaneidade, promove a participação livre e estimula a
              criatividade na produção dramática e na catarse ativa.
            </p>
          </div>
          <a
            href="https://febrap.org.br/o-que-e/"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex w-fit items-center gap-2 text-sm text-primary underline decoration-sage decoration-2 underline-offset-4 hover:decoration-primary"
          >
            Saiba mais sobre o Psicodrama →
          </a>
        </div>
      </div>
    </section>
  );
}

function ForWhom() {
  const items = [
    "Vivem com ansiedade ou sensação constante de alerta",
    "Sentem-se emocionalmente cansadas",
    "Enfrentam dificuldades nos relacionamentos",
    "Lidam com conflitos no trabalho ou na carreira",
    "Têm dificuldade em colocar limites",
    "Desejam se conhecer melhor e cuidar da saúde emocional",
  ];
  return (
    <section data-reveal className="border-t border-border/60 bg-cream">
      <div className="mx-auto max-w-6xl px-6 py-20 md:py-28">
        <div className="max-w-2xl">
          <p className="text-xs uppercase tracking-widest text-sage-deep">Para quem</p>
          <h2 className="mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl">
            A psicoterapia pode ser indicada para mulheres que...
          </h2>
        </div>
        <ul className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-2">
          {items.map((item, i) => (
            <li
              key={item}
              className="group flex items-start gap-4 rounded-2xl border border-sage/30 bg-background p-6 shadow-sm transition-all hover:-translate-y-1 hover:border-sage hover:shadow-lg"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary font-serif text-sm text-primary-foreground tabular-nums shadow-sm transition-colors group-hover:bg-sage-deep">
                0{i + 1}
              </span>
              <p className="text-base leading-relaxed text-primary">{item}</p>
            </li>
          ))}
        </ul>
        <div className="mt-12 flex flex-col items-center gap-3 text-center">
          <p className="max-w-md text-sm text-muted-foreground">
            Se você se identificou com algum desses pontos, podemos conversar.
          </p>
          <a
            href={WHATSAPP}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 text-sm text-primary-foreground shadow-sm transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-sage-deep hover:shadow-lg active:translate-y-0 active:scale-[0.97] motion-reduce:transform-none motion-reduce:transition-none"
          >
            Agende sua sessão
            <span aria-hidden className="transition-transform duration-300 ease-out group-hover:translate-x-1">→</span>
          </a>
        </div>
      </div>
    </section>
  );
}


function Ethics() {
  return (
    <section data-reveal className="border-t border-border/60">
      <div className="mx-auto max-w-4xl px-6 py-20 text-center md:py-24">
        <p className="text-xs uppercase tracking-widest text-sage">Ética e sigilo</p>
        <h2 className="mt-3 font-serif text-2xl leading-tight text-primary md:text-3xl">
          O atendimento psicológico é realizado com base nos princípios éticos
          da Psicologia, garantindo sigilo, respeito e cuidado com cada processo.
        </h2>
        <p className="mt-6 font-serif text-sage">CRP 09/19524</p>
      </div>
    </section>
  );
}

function Faq() {
  const items = [
    {
      q: "Como funciona a psicoterapia online?",
      a: "As sessões acontecem semanalmente, com duração média de 50 minutos, em uma plataforma de vídeo segura e sigilosa. Você só precisa de um ambiente reservado e uma boa conexão.",
    },
    {
      q: "O que é o Psicodrama?",
      a: "É a abordagem teórica que embasa meus atendimentos. Trabalha com a espontaneidade e a expressão emocional, ampliando a consciência sobre si mesma e ajudando a experimentar novas formas de existir.",
    },
    {
      q: "Quando procurar o Plantão Psicológico?",
      a: "Quando você está atravessando um momento de crise, urgência emocional ou precisa de uma escuta pontual, sem o compromisso de iniciar um processo terapêutico contínuo. É uma sessão única de acolhimento.",
    },
    {
      q: "Como é a Consultoria de Carreira?",
      a: "São encontros únicos em que analisamos juntas o seu momento profissional: transição de carreira, busca por um novo emprego, reposicionamento ou dúvidas sobre próximos passos.",
    },
    {
      q: "Preciso de encaminhamento médico para começar?",
      a: "Não. Você pode me procurar diretamente pelo WhatsApp. Se for necessário, indico o suporte de outros profissionais em conjunto ao processo.",
    },
    {
      q: "Qual o valor e forma de pagamento?",
      a: "Os valores e formas de pagamento são combinados no primeiro contato, de acordo com a modalidade escolhida. Fale comigo pelo WhatsApp para mais informações.",
    },
  ];
  return (
    <section data-reveal id="faq" className="border-t border-border/60 bg-cream">
      <div className="mx-auto max-w-4xl px-6 py-20 md:py-28">
        <div className="text-center">
          <p className="text-xs uppercase tracking-widest text-sage">Dúvidas</p>
          <h2 className="mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl">
            Perguntas frequentes
          </h2>
        </div>
        <div className="mt-12 divide-y divide-border/60 border-y border-border/60">
          {items.map((item) => (
            <details
              key={item.q}
              className="group py-6 [&_summary::-webkit-details-marker]:hidden"
            >
              <summary className="flex cursor-pointer items-start justify-between gap-6 list-none">
                <h3 className="font-serif text-lg text-primary md:text-xl">
                  {item.q}
                </h3>
                <span
                  aria-hidden
                  className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-sage text-sage transition-transform group-open:rotate-45"
                >
                  +
                </span>
              </summary>
              <p className="mt-4 pr-12 text-base leading-relaxed text-muted-foreground">
                {item.a}
              </p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section data-reveal id="contato" className="border-t border-border/60 bg-primary text-primary-foreground">
      <div className="mx-auto max-w-6xl px-6 py-20 md:py-28">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-2 md:items-end">
          <div>
            <p className="text-xs uppercase tracking-widest text-sage-soft/80">
              Agendamento
            </p>
            <h2 className="mt-3 font-serif text-4xl leading-tight md:text-6xl">
              Se você sentir que é o momento, estou à disposição.
            </h2>
          </div>
          <div>
            <p className="text-base leading-relaxed text-primary-foreground/80">
              Envie uma mensagem pelo WhatsApp e vamos conversar sobre o que faz
              sentido para o seu momento.
            </p>
            <a
              href={WHATSAPP}
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-8 inline-flex items-center gap-3 rounded-full bg-cream px-7 py-4 text-primary shadow-sm transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-sage-soft hover:shadow-lg active:translate-y-0 active:scale-[0.97] active:shadow-md motion-reduce:transform-none motion-reduce:transition-none"
            >
              <span className="text-sm">Agende sua sessão</span>
              <span aria-hidden className="transition-transform duration-300 ease-out group-hover:translate-x-1">→</span>
            </a>
            <p className="mt-6 text-xs uppercase tracking-widest text-primary-foreground/60">
              Online · Todo Brasil e exterior
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground/70">
      <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 border-t border-primary-foreground/10 px-6 py-10 md:flex-row md:items-center">
        <div>
          <p className="font-serif text-lg text-primary-foreground">
            Thamyres Meireles
          </p>
          <p className="mt-1 text-xs uppercase tracking-widest">
            Psicóloga Clínica · CRP 09/19524
          </p>
        </div>
        <p className="text-xs">
          © {new Date().getFullYear()} Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
}
