//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DZsIDEV3.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/dev-server/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BPGPZMq0.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BPGPZMq0.js"
		} }]
	},
	"/": {
		filePath: "/dev-server/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CTpmNBQt.js"]
	}
} });
//#endregion
export { tsrStartManifest };
