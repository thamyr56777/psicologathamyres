import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BLMGmT4U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var hero_garden_jpg_asset_default = {
	version: 1,
	asset_id: "ff60a427-06ae-46ae-aae2-a31a2d2416f9",
	project_id: "8bdb3511-c5a3-417e-ad5f-d39cb673dc4f",
	url: "/__l5e/assets-v1/ff60a427-06ae-46ae-aae2-a31a2d2416f9/hero-garden.jpg",
	r2_key: "a/v1/8bdb3511-c5a3-417e-ad5f-d39cb673dc4f/ff60a427-06ae-46ae-aae2-a31a2d2416f9/hero-garden.jpg",
	original_filename: "hero-garden.jpg",
	size: 187638,
	content_type: "image/jpeg",
	created_at: "2026-07-15T00:27:54Z"
};
var thamyres_jpg_asset_default = {
	version: 1,
	asset_id: "9202557a-b832-46ef-ae97-887edf126dda",
	project_id: "8bdb3511-c5a3-417e-ad5f-d39cb673dc4f",
	url: "/__l5e/assets-v1/9202557a-b832-46ef-ae97-887edf126dda/thamyres.jpg",
	r2_key: "a/v1/8bdb3511-c5a3-417e-ad5f-d39cb673dc4f/9202557a-b832-46ef-ae97-887edf126dda/thamyres.jpg",
	original_filename: "thamyres.jpg",
	size: 3132506,
	content_type: "image/jpeg",
	created_at: "2026-07-15T00:25:36Z"
};
var psicodrama_livro_jpg_asset_default = {
	version: 1,
	asset_id: "c4a4c1e3-b6ac-4b1c-9e53-785a38aacaaa",
	project_id: "8bdb3511-c5a3-417e-ad5f-d39cb673dc4f",
	url: "/__l5e/assets-v1/c4a4c1e3-b6ac-4b1c-9e53-785a38aacaaa/psicodrama-livro.jpg",
	r2_key: "a/v1/8bdb3511-c5a3-417e-ad5f-d39cb673dc4f/c4a4c1e3-b6ac-4b1c-9e53-785a38aacaaa/psicodrama-livro.jpg",
	original_filename: "psicodrama-livro.jpg",
	size: 2932186,
	content_type: "image/jpeg",
	created_at: "2026-07-15T00:37:10Z"
};
function useReveal() {
	(0, import_react.useEffect)(() => {
		const els = document.querySelectorAll("[data-reveal]");
		if (!els.length) return;
		if (typeof IntersectionObserver === "undefined") {
			els.forEach((el) => el.setAttribute("data-reveal", "in"));
			return;
		}
		const io = new IntersectionObserver((entries) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) {
					entry.target.setAttribute("data-reveal", "in");
					io.unobserve(entry.target);
				}
			});
		}, {
			threshold: .12,
			rootMargin: "0px 0px -8% 0px"
		});
		els.forEach((el) => io.observe(el));
		return () => io.disconnect();
	}, []);
}
var WHATSAPP = "https://wa.me/5562998050979?text=Ol%C3%A1%2C%20Thamyres!%20Gostaria%20de%20mais%20informa%C3%A7%C3%B5es%20sobre%20seus%20atendimentos.";
function Index() {
	useReveal();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowItWorks, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Psicodrama, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ForWhom, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ethics, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
function Nav() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "absolute top-0 left-0 right-0 z-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center justify-between px-6 py-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#top",
					className: "font-serif text-lg tracking-tight text-primary",
					children: "Thamyres Meireles"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-8 text-sm text-muted-foreground md:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#sobre",
							className: "hover:text-primary transition-colors",
							children: "Sobre"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#servicos",
							className: "hover:text-primary transition-colors",
							children: "Serviços"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#psicodrama",
							className: "hover:text-primary transition-colors",
							children: "Psicodrama"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#contato",
							className: "hover:text-primary transition-colors",
							children: "Contato"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: WHATSAPP,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "hidden rounded-full border border-primary/30 bg-background/60 px-4 py-2 text-sm text-primary backdrop-blur transition-colors hover:bg-primary hover:text-primary-foreground md:inline-flex",
					children: "Agendar"
				})
			]
		})
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "top",
		className: "relative overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl grid-cols-1 gap-10 px-6 pt-32 pb-20 md:grid-cols-2 md:gap-16 md:pt-40 md:pb-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mb-6 inline-flex w-fit items-center gap-2 rounded-full bg-sage-soft px-3 py-1 text-xs uppercase tracking-widest text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-primary" }), "Psicóloga Clínica · CRP 09/19524"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-serif text-4xl leading-[1.05] text-primary md:text-6xl",
						children: [
							"Um espaço seguro para cuidar da sua",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic text-sage",
								children: "saúde emocional"
							}),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-lg text-base leading-relaxed text-muted-foreground md:text-lg",
						children: "Atendo mulheres adultas que lidam com ansiedade, dificuldades nos relacionamentos e sofrimento ligado ao trabalho e à carreira, com uma escuta ética, acolhedora e respeitosa."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: WHATSAPP,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm text-primary-foreground transition-all hover:bg-sage-deep hover:shadow-lg",
							children: ["Agendar atendimento", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								children: "→"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#sobre",
							className: "inline-flex items-center rounded-full border border-primary/20 px-6 py-3 text-sm text-primary transition-colors hover:bg-sage-soft",
							children: "Conhecer meu trabalho"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-xs uppercase tracking-widest text-muted-foreground",
						children: "Atendimento online · Brasil e exterior"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative overflow-hidden rounded-[2rem] bg-sage-soft aspect-[4/5]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: hero_garden_jpg_asset_default.url,
						alt: "Jardim ao entardecer com duas cadeiras brancas entre flores",
						width: 1400,
						height: 1600,
						className: "h-full w-full object-cover"
					})
				})
			})]
		})
	});
}
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"data-reveal": true,
		id: "sobre",
		className: "border-t border-border/60 bg-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl grid-cols-1 gap-12 px-6 py-20 md:grid-cols-5 md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-[2rem] aspect-[4/5]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: thamyres_jpg_asset_default.url,
						alt: "Thamyres Meireles, psicóloga clínica",
						width: 1e3,
						height: 1200,
						loading: "lazy",
						className: "h-full w-full object-cover"
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-3 md:pl-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-sage",
						children: "Apresentação"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl",
						children: "Sou Thamyres Meireles, psicóloga clínica."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 space-y-4 text-base leading-relaxed text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Minha atuação é guiada pelo cuidado com a saúde emocional e pelo respeito à singularidade de cada pessoa. Acredito na psicoterapia como um espaço de encontro consigo, de elaboração das dores e de construção de novas possibilidades de existir." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Sou formada pela Pontifícia Universidade Católica de Goiás, com mérito acadêmico ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Summa Cum Laude" }),
							", e atuo com a abordagem do ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-primary font-medium",
								children: "Psicodrama"
							}),
							", que favorece a expressão emocional, a ampliação da consciência e o fortalecimento da espontaneidade."
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-10 grid grid-cols-2 gap-6 border-t border-border/60 pt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-sage",
							children: "Registro"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-serif text-xl text-primary",
							children: "CRP 09/19524"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-sage",
							children: "Abordagem"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-serif text-xl text-primary",
							children: "Psicodrama"
						})] })]
					})
				]
			})]
		})
	});
}
var services = [
	{
		title: "Psicoterapia",
		desc: "Acompanhamento contínuo para mulheres adultas, em encontros semanais de 50 minutos, com escuta ética e vínculo terapêutico.",
		tag: "Semanal"
	},
	{
		title: "Plantão Psicológico",
		desc: "Atendimento pontual para momentos de crise, urgência emocional ou quando você precisa de escuta imediata, sem compromisso de continuidade.",
		tag: "Sessão única"
	},
	{
		title: "Consultoria de Carreira",
		desc: "Encontros únicos para analisar juntas as possibilidades do momento: transição de carreira, busca por um novo emprego e reposicionamento profissional.",
		tag: "Encontro único"
	}
];
function Services() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"data-reveal": true,
		id: "servicos",
		className: "border-t border-border/60",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-6 py-20 md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-start justify-between gap-6 md:flex-row md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-sage",
						children: "Serviços"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl",
						children: "Cuidado que respeita o seu tempo."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm text-muted-foreground",
					children: "Três formas de acompanhamento, pensadas para diferentes momentos da vida. Todos os atendimentos acontecem online."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 grid grid-cols-1 gap-6 md:grid-cols-3",
				children: services.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "group relative flex flex-col justify-between rounded-3xl border border-border/70 bg-card p-8 transition-all hover:border-sage hover:shadow-lg hover:-translate-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex items-center rounded-full bg-sage-soft px-3 py-1 text-[10px] uppercase tracking-widest text-primary",
							children: s.tag
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-6 font-serif text-2xl text-primary",
							children: s.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-muted-foreground",
							children: s.desc
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex items-center justify-between border-t border-border/60 pt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-serif text-sm text-sage",
							children: ["0", i + 1]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: WHATSAPP,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "text-xs uppercase tracking-widest text-primary transition-colors group-hover:text-sage-deep",
							children: "Agendar →"
						})]
					})]
				}, s.title))
			})]
		})
	});
}
function HowItWorks() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"data-reveal": true,
		className: "border-t border-border/60 bg-sage-soft/40",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-6 py-20 md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-sage",
						children: "Como funciona"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl",
						children: "Um processo construído em conjunto."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-base leading-relaxed text-muted-foreground",
						children: "A psicoterapia se constrói a partir da escuta, do vínculo e do respeito ao seu tempo — conforme as normas do Conselho Federal de Psicologia."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-14 grid grid-cols-1 gap-8 md:grid-cols-3",
				children: [
					{
						n: "01",
						t: "Primeiro contato",
						d: "Você me escreve pelo WhatsApp e conversamos brevemente sobre a sua demanda."
					},
					{
						n: "02",
						t: "Sessão inicial",
						d: "Nosso primeiro encontro é um espaço para nos conhecermos e alinharmos objetivos."
					},
					{
						n: "03",
						t: "Processo terapêutico",
						d: "Encontros semanais de 50 minutos, online, em plataforma segura e sigilosa."
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative border-t border-primary/20 pt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-serif text-3xl text-sage",
							children: s.n
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 font-serif text-xl text-primary",
							children: s.t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted-foreground",
							children: s.d
						})
					]
				}, s.n))
			})]
		})
	});
}
function Psicodrama() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"data-reveal": true,
		id: "psicodrama",
		className: "border-t border-border/60",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl grid-cols-1 gap-12 px-6 py-20 md:grid-cols-2 md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "order-2 md:order-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-[2rem] aspect-[4/3]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: psicodrama_livro_jpg_asset_default.url,
						alt: "Thamyres sorrindo, segurando o livro Lições de Psicodrama",
						width: 1200,
						height: 900,
						loading: "lazy",
						className: "h-full w-full object-cover"
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "order-1 flex flex-col justify-center md:order-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-sage",
						children: "Abordagem"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl",
						children: "Psicodrama: espontaneidade e presença."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 space-y-4 text-base leading-relaxed text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "O Psicodrama é facilitador da manifestação das ideias, dos conflitos sobre um tema, dos dilemas morais, impedimentos e possibilidades de expressão em determinada situação." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Fundamentado na teoria do momento e no princípio da espontaneidade, promove a participação livre e estimula a criatividade na produção dramática e na catarse ativa." })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://febrap.org.br/o-que-e/",
						target: "_blank",
						rel: "noopener noreferrer",
						className: "mt-8 inline-flex w-fit items-center gap-2 text-sm text-primary underline decoration-sage decoration-2 underline-offset-4 hover:decoration-primary",
						children: "Saiba mais sobre o Psicodrama →"
					})
				]
			})]
		})
	});
}
function ForWhom() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"data-reveal": true,
		className: "border-t border-border/60 bg-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-6 py-20 md:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-sage-deep",
						children: "Para quem"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl",
						children: "A psicoterapia pode ser indicada para mulheres que..."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-12 grid grid-cols-1 gap-5 md:grid-cols-2",
					children: [
						"Vivem com ansiedade ou sensação constante de alerta",
						"Sentem-se emocionalmente cansadas",
						"Enfrentam dificuldades nos relacionamentos",
						"Lidam com conflitos no trabalho ou na carreira",
						"Têm dificuldade em colocar limites",
						"Desejam se conhecer melhor e cuidar da saúde emocional"
					].map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "group flex items-start gap-4 rounded-2xl border border-sage/30 bg-background p-6 shadow-sm transition-all hover:-translate-y-1 hover:border-sage hover:shadow-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary font-serif text-sm text-primary-foreground tabular-nums shadow-sm transition-colors group-hover:bg-sage-deep",
							children: ["0", i + 1]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base leading-relaxed text-primary",
							children: item
						})]
					}, item))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-12 flex flex-col items-center gap-3 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-md text-sm text-muted-foreground",
						children: "Se você se identificou com algum desses pontos, podemos conversar."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: WHATSAPP,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "group inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 text-sm text-primary-foreground shadow-sm transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-sage-deep hover:shadow-lg active:translate-y-0 active:scale-[0.97] motion-reduce:transform-none motion-reduce:transition-none",
						children: ["Agende sua sessão", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: "transition-transform duration-300 ease-out group-hover:translate-x-1",
							children: "→"
						})]
					})]
				})
			]
		})
	});
}
function Ethics() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"data-reveal": true,
		className: "border-t border-border/60",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-6 py-20 text-center md:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-sage",
					children: "Ética e sigilo"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-2xl leading-tight text-primary md:text-3xl",
					children: "O atendimento psicológico é realizado com base nos princípios éticos da Psicologia, garantindo sigilo, respeito e cuidado com cada processo."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 font-serif text-sage",
					children: "CRP 09/19524"
				})
			]
		})
	});
}
function Faq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"data-reveal": true,
		id: "faq",
		className: "border-t border-border/60 bg-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-6 py-20 md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-sage",
					children: "Dúvidas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-3xl leading-tight text-primary md:text-5xl",
					children: "Perguntas frequentes"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 divide-y divide-border/60 border-y border-border/60",
				children: [
					{
						q: "Como funciona a psicoterapia online?",
						a: "As sessões acontecem semanalmente, com duração média de 50 minutos, em uma plataforma de vídeo segura e sigilosa. Você só precisa de um ambiente reservado e uma boa conexão."
					},
					{
						q: "O que é o Psicodrama?",
						a: "É a abordagem teórica que embasa meus atendimentos. Trabalha com a espontaneidade e a expressão emocional, ampliando a consciência sobre si mesma e ajudando a experimentar novas formas de existir."
					},
					{
						q: "Quando procurar o Plantão Psicológico?",
						a: "Quando você está atravessando um momento de crise, urgência emocional ou precisa de uma escuta pontual, sem o compromisso de iniciar um processo terapêutico contínuo. É uma sessão única de acolhimento."
					},
					{
						q: "Como é a Consultoria de Carreira?",
						a: "São encontros únicos em que analisamos juntas o seu momento profissional: transição de carreira, busca por um novo emprego, reposicionamento ou dúvidas sobre próximos passos."
					},
					{
						q: "Preciso de encaminhamento médico para começar?",
						a: "Não. Você pode me procurar diretamente pelo WhatsApp. Se for necessário, indico o suporte de outros profissionais em conjunto ao processo."
					},
					{
						q: "Qual o valor e forma de pagamento?",
						a: "Os valores e formas de pagamento são combinados no primeiro contato, de acordo com a modalidade escolhida. Fale comigo pelo WhatsApp para mais informações."
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "group py-6 [&_summary::-webkit-details-marker]:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
						className: "flex cursor-pointer items-start justify-between gap-6 list-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-serif text-lg text-primary md:text-xl",
							children: item.q
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: "mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-sage text-sage transition-transform group-open:rotate-45",
							children: "+"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 pr-12 text-base leading-relaxed text-muted-foreground",
						children: item.a
					})]
				}, item.q))
			})]
		})
	});
}
function Contact() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		"data-reveal": true,
		id: "contato",
		className: "border-t border-border/60 bg-primary text-primary-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-6xl px-6 py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-12 md:grid-cols-2 md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-sage-soft/80",
					children: "Agendamento"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-4xl leading-tight md:text-6xl",
					children: "Se você sentir que é o momento, estou à disposição."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base leading-relaxed text-primary-foreground/80",
						children: "Envie uma mensagem pelo WhatsApp e vamos conversar sobre o que faz sentido para o seu momento."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: WHATSAPP,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "group mt-8 inline-flex items-center gap-3 rounded-full bg-cream px-7 py-4 text-primary shadow-sm transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-sage-soft hover:shadow-lg active:translate-y-0 active:scale-[0.97] active:shadow-md motion-reduce:transform-none motion-reduce:transition-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Agende sua sessão"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: "transition-transform duration-300 ease-out group-hover:translate-x-1",
							children: "→"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-xs uppercase tracking-widest text-primary-foreground/60",
						children: "Online · Todo Brasil e exterior"
					})
				] })]
			})
		})
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "bg-primary text-primary-foreground/70",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 border-t border-primary-foreground/10 px-6 py-10 md:flex-row md:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-serif text-lg text-primary-foreground",
				children: "Thamyres Meireles"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs uppercase tracking-widest",
				children: "Psicóloga Clínica · CRP 09/19524"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs",
				children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Todos os direitos reservados."
				]
			})]
		})
	});
}
//#endregion
export { Index as component };
